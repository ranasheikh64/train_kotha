
  # Mobile View Design

  This is a code bundle for Mobile View Design. The original project is available at https://www.figma.com/design/BpmWRIX44H8XlknyQ9tqqX/Mobile-View-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  