import { useState } from "react";
import { Folder, Video, Music, Image, FileText, Search, Grid, List, MoreVertical, Trash2, Share2, Move, Info, CheckSquare, Square, SortAsc, ChevronRight } from "lucide-react";

type FileCategory = "All" | "Videos" | "Audio" | "Images" | "Documents";

const fileCategories = [
  { id: "All", label: "All", icon: Folder, color: "#8b5cf6", count: 34, size: "12.4 GB" },
  { id: "Videos", label: "Videos", icon: Video, color: "#3b82f6", count: 18, size: "9.8 GB" },
  { id: "Audio", label: "Audio", icon: Music, color: "#10b981", count: 7, size: "1.2 GB" },
  { id: "Images", label: "Images", icon: Image, color: "#f59e0b", count: 6, size: "840 MB" },
  { id: "Documents", label: "Docs", icon: FileText, color: "#ef4444", count: 3, size: "12 MB" },
];

const files = [
  { id: 1, name: "Epic_Mountain_4K.mp4", type: "Videos", size: "1.2 GB", date: "Today, 10:42", duration: "8:32", source: "youtube.com", thumb: "🎬" },
  { id: 2, name: "World_Tour_Concert.mp4", type: "Videos", size: "648 MB", date: "Today, 09:15", duration: "45:12", source: "instagram.com", thumb: "🎵" },
  { id: 3, name: "iPhone_17_Review.mp4", type: "Videos", size: "324 MB", date: "Yesterday", duration: "22:17", source: "youtube.com", thumb: "📱" },
  { id: 4, name: "Champions_League.mp4", type: "Videos", size: "980 MB", date: "Yesterday", duration: "12:05", source: "facebook.com", thumb: "⚽" },
  { id: 5, name: "Hidden_Gems_Asia.mp4", type: "Videos", size: "512 MB", date: "2 days ago", duration: "18:44", source: "vimeo.com", thumb: "🌏" },
  { id: 6, name: "Gordon_Pasta_Recipe.mp4", type: "Videos", size: "87 MB", date: "2 days ago", duration: "14:30", source: "tiktok.com", thumb: "🍝" },
  { id: 7, name: "Summer_Vibes_Mix.mp3", type: "Audio", size: "42 MB", date: "3 days ago", duration: "1:12:30", source: "soundcloud.com", thumb: "🎧" },
  { id: 8, name: "Podcast_Episode_42.m4a", type: "Audio", size: "128 MB", date: "3 days ago", duration: "2:04:11", source: "youtube.com", thumb: "🎙" },
  { id: 9, name: "Sunset_Wallpaper.jpg", type: "Images", size: "8.2 MB", date: "4 days ago", duration: "", source: "unsplash.com", thumb: "🌅" },
  { id: 10, name: "Tutorial_Subtitles.srt", type: "Documents", size: "24 KB", date: "5 days ago", duration: "", source: "youtube.com", thumb: "📄" },
];

export default function FilesScreen() {
  const [activeCategory, setActiveCategory] = useState<FileCategory>("All");
  const [viewMode, setViewMode] = useState<"list" | "grid">("list");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [sortBy, setSortBy] = useState("date");
  const [actionFileId, setActionFileId] = useState<number | null>(null);

  const isSelecting = selectedIds.length > 0;

  const toggleSelect = (id: number) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const filteredFiles = files.filter(f => {
    const catMatch = activeCategory === "All" || f.type === activeCategory;
    const searchMatch = f.name.toLowerCase().includes(searchQuery.toLowerCase());
    return catMatch && searchMatch;
  });

  const getCategoryInfo = (cat: FileCategory) => fileCategories.find(c => c.id === cat);

  return (
    <div className="flex flex-col h-full bg-[#0f0f13] text-white overflow-hidden">
      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 pt-2 pb-1">
        <span className="text-xs text-gray-400">9:41</span>
        <div className="w-5 h-2.5 rounded-sm border border-white/60 p-px">
          <div className="h-full w-4/5 bg-green-400 rounded-sm" />
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <h1 className="text-white" style={{fontSize:'17px',fontWeight:700}}>
          {isSelecting ? `${selectedIds.length} selected` : "Files"}
        </h1>
        <div className="flex gap-2">
          {isSelecting ? (
            <>
              <button
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/10"
                onClick={() => setSelectedIds([])}
                style={{fontSize:'11px'}}
              >
                <span className="text-gray-300">Cancel</span>
              </button>
              <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-red-500/20 border border-red-500/30">
                <Trash2 size={13} className="text-red-400" />
              </button>
              <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/10">
                <Share2 size={13} className="text-gray-300" />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setShowSortMenu(!showSortMenu)}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/8 border border-white/10"
                style={{fontSize:'11px'}}
              >
                <SortAsc size={13} className="text-gray-300" />
              </button>
              <button
                onClick={() => setViewMode(v => v === "list" ? "grid" : "list")}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/8 border border-white/10"
              >
                {viewMode === "list" ? <Grid size={13} className="text-gray-300" /> : <List size={13} className="text-gray-300" />}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Category Cards */}
      <div className="flex gap-2 px-4 overflow-x-auto pb-2" style={{scrollbarWidth:'none'}}>
        {fileCategories.map(cat => {
          const Icon = cat.icon;
          const active = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as FileCategory)}
              className={`shrink-0 flex items-center gap-2 px-3 py-2 rounded-xl border transition-all ${
                active ? "border-opacity-40 bg-opacity-20" : "border-white/10 bg-white/5"
              }`}
              style={{
                borderColor: active ? cat.color : undefined,
                backgroundColor: active ? `${cat.color}20` : undefined,
              }}
            >
              <Icon size={13} style={{color: cat.color}} />
              <div className="text-left">
                <p style={{fontSize:'11px',fontWeight:600,color:active?'white':'#9ca3af'}}>{cat.label}</p>
                <p style={{fontSize:'9px',color:active?cat.color:'#6b7280'}}>{cat.count} • {cat.size}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Search */}
      <div className="px-4 pb-2">
        <div className="flex items-center gap-2 bg-[#1e1e2a] rounded-xl px-3 py-2 border border-white/10">
          <Search size={14} className="text-gray-500 shrink-0" />
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search files..."
            className="flex-1 bg-transparent text-white placeholder:text-gray-600 outline-none"
            style={{fontSize:'12px'}}
          />
        </div>
      </div>

      {/* File List */}
      <div className="flex-1 overflow-y-auto px-4 pb-4" style={{scrollbarWidth:'none'}}>
        {viewMode === "list" ? (
          <div className="space-y-1.5">
            {filteredFiles.map(file => {
              const selected = selectedIds.includes(file.id);
              const cat = fileCategories.find(c => c.id === file.type);
              return (
                <div
                  key={file.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${selected ? "border-violet-500/40 bg-violet-600/10" : "border-white/8 bg-white/4"}`}
                  onClick={() => isSelecting ? toggleSelect(file.id) : undefined}
                >
                  {isSelecting && (
                    <div onClick={() => toggleSelect(file.id)}>
                      {selected
                        ? <CheckSquare size={16} className="text-violet-400 shrink-0" />
                        : <Square size={16} className="text-gray-500 shrink-0" />
                      }
                    </div>
                  )}
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{backgroundColor:`${cat?.color}20`}}
                  >
                    <span style={{fontSize:'20px'}}>{file.thumb}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-white leading-tight truncate" style={{fontSize:'12px',fontWeight:500}}>{file.name}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-gray-500" style={{fontSize:'10px'}}>{file.size}</span>
                      {file.duration && (
                        <>
                          <span className="text-gray-600">·</span>
                          <span className="text-gray-500" style={{fontSize:'10px'}}>{file.duration}</span>
                        </>
                      )}
                      <span className="text-gray-600">·</span>
                      <span className="text-gray-500" style={{fontSize:'10px'}}>{file.date}</span>
                    </div>
                    <p className="text-gray-600" style={{fontSize:'9px'}}>{file.source}</p>
                  </div>
                  {!isSelecting && (
                    <button
                      onClick={() => setActionFileId(actionFileId === file.id ? null : file.id)}
                      className="p-1.5 rounded-lg bg-white/8"
                    >
                      <MoreVertical size={13} className="text-gray-400" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {filteredFiles.map(file => {
              const selected = selectedIds.includes(file.id);
              return (
                <div
                  key={file.id}
                  className={`p-3 rounded-xl border ${selected ? "border-violet-500/40 bg-violet-600/10" : "border-white/8 bg-white/4"}`}
                  onClick={() => toggleSelect(file.id)}
                >
                  <div className="w-full h-16 rounded-lg bg-white/8 flex items-center justify-center mb-2">
                    <span style={{fontSize:'32px'}}>{file.thumb}</span>
                  </div>
                  <p className="text-white truncate" style={{fontSize:'11px',fontWeight:500}}>{file.name}</p>
                  <p className="text-gray-500" style={{fontSize:'9px'}}>{file.size} · {file.date}</p>
                </div>
              );
            })}
          </div>
        )}

        {filteredFiles.length === 0 && (
          <div className="flex flex-col items-center justify-center py-10">
            <Folder size={32} className="text-gray-600 mb-3" />
            <p className="text-gray-400" style={{fontSize:'13px'}}>No files found</p>
          </div>
        )}
      </div>

      {/* File Action Sheet */}
      {actionFileId && (
        <div className="absolute inset-0 bg-black/70 z-50 flex items-end" onClick={() => setActionFileId(null)}>
          <div className="w-full bg-[#1a1a24] rounded-t-3xl p-4 border-t border-white/10" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-4" />
            {(() => {
              const f = files.find(f => f.id === actionFileId);
              return (
                <>
                  <p className="text-white mb-1 truncate" style={{fontSize:'13px',fontWeight:600}}>{f?.name}</p>
                  <p className="text-gray-400 mb-4" style={{fontSize:'11px'}}>{f?.size} · {f?.date}</p>
                </>
              );
            })()}
            {[
              { icon: Share2, label: "Share", color: "#8b5cf6" },
              { icon: Move, label: "Move to Vault", color: "#10b981" },
              { icon: Info, label: "File Info", color: "#3b82f6" },
              { icon: Trash2, label: "Delete", color: "#ef4444" },
            ].map(action => {
              const Icon = action.icon;
              return (
                <button
                  key={action.label}
                  className="w-full flex items-center gap-3 p-3 rounded-xl mb-2 bg-white/5 border border-white/8"
                  onClick={() => setActionFileId(null)}
                >
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{backgroundColor:`${action.color}20`}}>
                    <Icon size={16} style={{color:action.color}} />
                  </div>
                  <span className="text-white" style={{fontSize:'13px',fontWeight:500}}>{action.label}</span>
                  <ChevronRight size={14} className="text-gray-500 ml-auto" />
                </button>
              );
            })}
            <button onClick={() => setActionFileId(null)} className="w-full py-2.5 rounded-xl bg-white/10 text-gray-300 mt-1" style={{fontSize:'13px',fontWeight:600}}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Sort Menu */}
      {showSortMenu && (
        <div className="absolute top-28 right-4 bg-[#1a1a24] rounded-2xl border border-white/10 p-2 z-40 shadow-xl">
          {["date","name","size","type"].map(s => (
            <button
              key={s}
              className={`flex items-center gap-2 w-full px-3 py-2 rounded-xl ${sortBy===s?"bg-violet-600/20 text-violet-400":"text-gray-300"}`}
              style={{fontSize:'12px',fontWeight:sortBy===s?600:400}}
              onClick={() => { setSortBy(s); setShowSortMenu(false); }}
            >
              <SortAsc size={13} />
              Sort by {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
