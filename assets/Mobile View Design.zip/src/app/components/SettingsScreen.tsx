import { useState } from "react";
import { Moon, Sun, Wifi, Globe, HardDrive, Download, Bell, Lock, Shield, Trash2, ChevronRight, ToggleLeft, ToggleRight, Volume2, Sliders, Smartphone, RefreshCw, Info, Star, Share2 } from "lucide-react";

interface ToggleProps {
  value: boolean;
  onChange: (v: boolean) => void;
  color?: string;
}

function Toggle({ value, onChange, color = "#8b5cf6" }: ToggleProps) {
  return (
    <button
      onClick={() => onChange(!value)}
      className="relative w-10 h-5.5 rounded-full transition-all shrink-0"
      style={{
        backgroundColor: value ? color : "#374151",
        width: 40,
        height: 22,
      }}
    >
      <div
        className="absolute top-0.5 rounded-full bg-white shadow-sm transition-all duration-200"
        style={{
          width: 18,
          height: 18,
          left: value ? 20 : 2,
        }}
      />
    </button>
  );
}

interface SettingItemProps {
  icon: React.ReactNode;
  label: string;
  sublabel?: string;
  right?: React.ReactNode;
  onClick?: () => void;
  iconBg?: string;
}

function SettingItem({ icon, label, sublabel, right, onClick, iconBg = "#1e1e2a" }: SettingItemProps) {
  return (
    <button
      className="flex items-center gap-3 w-full py-3 border-b border-white/5 last:border-0"
      onClick={onClick}
    >
      <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{backgroundColor:iconBg}}>
        {icon}
      </div>
      <div className="flex-1 text-left min-w-0">
        <p className="text-white" style={{fontSize:'13px',fontWeight:500}}>{label}</p>
        {sublabel && <p className="text-gray-500" style={{fontSize:'11px'}}>{sublabel}</p>}
      </div>
      {right || <ChevronRight size={14} className="text-gray-600 shrink-0" />}
    </button>
  );
}

interface SectionProps {
  title: string;
  children: React.ReactNode;
}

function Section({ title, children }: SectionProps) {
  return (
    <div className="mb-4">
      <p className="text-gray-500 px-4 mb-1.5 uppercase" style={{fontSize:'10px',letterSpacing:'0.08em',fontWeight:600}}>{title}</p>
      <div className="mx-4 bg-[#1a1a24] rounded-2xl px-4 border border-white/8">
        {children}
      </div>
    </div>
  );
}

export default function SettingsScreen() {
  const [darkMode, setDarkMode] = useState(true);
  const [wifiOnly, setWifiOnly] = useState(true);
  const [autoStart, setAutoStart] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [adultMode, setAdultMode] = useState(false);
  const [appLock, setAppLock] = useState(false);
  const [vpn, setVpn] = useState(false);
  const [doh, setDoh] = useState(true);
  const [concurrent, setConcurrent] = useState(4);
  const [quality, setQuality] = useState("1080p");
  const [showQualityPicker, setShowQualityPicker] = useState(false);
  const [showStorageInfo, setShowStorageInfo] = useState(false);

  const qualities = ["144p","240p","360p","480p","720p","1080p","1440p","4K"];

  return (
    <div className="flex flex-col h-full bg-[#0f0f13] text-white overflow-hidden">
      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 pt-2 pb-1">
        <span className="text-xs text-gray-400">9:41</span>
        <div className="w-5 h-2.5 rounded-sm border border-white/60 p-px">
          <div className="h-full w-4/5 bg-green-400 rounded-sm" />
        </div>
      </div>

      {/* Header */}
      <div className="px-4 py-2 mb-2">
        <h1 className="text-white" style={{fontSize:'17px',fontWeight:700}}>Settings</h1>
      </div>

      {/* Profile Card */}
      <div className="mx-4 mb-4 p-4 rounded-2xl border border-white/8 bg-gradient-to-r from-violet-900/30 to-blue-900/30">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500 to-blue-600 flex items-center justify-center" style={{fontSize:'22px'}}>
            ⚡
          </div>
          <div>
            <p className="text-white" style={{fontSize:'14px',fontWeight:700}}>VidGet Pro</p>
            <p className="text-gray-400" style={{fontSize:'11px'}}>v2.4.1 • All features unlocked</p>
          </div>
          <button className="ml-auto px-3 py-1.5 rounded-full border border-violet-500/40 text-violet-400" style={{fontSize:'11px',fontWeight:600}}>
            Manage
          </button>
        </div>
      </div>

      {/* Scrollable Settings */}
      <div className="flex-1 overflow-y-auto pb-4" style={{scrollbarWidth:'none'}}>

        <Section title="Appearance">
          <SettingItem
            icon={darkMode ? <Moon size={16} className="text-violet-400" /> : <Sun size={16} className="text-amber-400" />}
            label="Dark Mode"
            sublabel={darkMode ? "Dark theme active" : "Light theme active"}
            iconBg={darkMode ? "#2d1f5e" : "#422006"}
            right={<Toggle value={darkMode} onChange={setDarkMode} />}
          />
          <SettingItem
            icon={<Globe size={16} className="text-blue-400" />}
            label="App Language"
            sublabel="English"
            iconBg="#1e3a5f"
          />
          <SettingItem
            icon={<Volume2 size={16} className="text-green-400" />}
            label="Content Language"
            sublabel="English, Hindi, Bengali"
            iconBg="#14432a"
          />
        </Section>

        <Section title="Downloads">
          <SettingItem
            icon={<Sliders size={16} className="text-violet-400" />}
            label="Default Quality"
            sublabel={quality}
            iconBg="#2d1f5e"
            onClick={() => setShowQualityPicker(true)}
          />
          <SettingItem
            icon={<Download size={16} className="text-blue-400" />}
            label="Concurrent Downloads"
            sublabel={`${concurrent} at a time`}
            iconBg="#1e3a5f"
            right={
              <div className="flex items-center gap-2">
                <button onClick={() => setConcurrent(Math.max(1, concurrent - 1))} className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-white" style={{fontSize:'14px'}}>−</button>
                <span className="text-violet-400" style={{fontSize:'13px',fontWeight:700}}>{concurrent}</span>
                <button onClick={() => setConcurrent(Math.min(8, concurrent + 1))} className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center text-white" style={{fontSize:'14px'}}>+</button>
              </div>
            }
          />
          <SettingItem
            icon={<RefreshCw size={16} className="text-amber-400" />}
            label="Auto-Start Downloads"
            sublabel="Skip confirmation prompt"
            iconBg="#422006"
            right={<Toggle value={autoStart} onChange={setAutoStart} color="#f59e0b" />}
          />
          <SettingItem
            icon={<HardDrive size={16} className="text-green-400" />}
            label="Download Location"
            sublabel="Internal Storage / VidGet"
            iconBg="#14432a"
          />
        </Section>

        <Section title="Network">
          <SettingItem
            icon={<Wifi size={16} className="text-blue-400" />}
            label="Wi-Fi Only"
            sublabel="Pause on mobile data"
            iconBg="#1e3a5f"
            right={<Toggle value={wifiOnly} onChange={setWifiOnly} color="#3b82f6" />}
          />
          <SettingItem
            icon={<Globe size={16} className="text-violet-400" />}
            label="VPN / Proxy"
            sublabel={vpn ? "Configured" : "Not configured"}
            iconBg="#2d1f5e"
            right={<Toggle value={vpn} onChange={setVpn} />}
          />
          <SettingItem
            icon={<Shield size={16} className="text-green-400" />}
            label="DNS-over-HTTPS"
            sublabel="Encrypted DNS"
            iconBg="#14432a"
            right={<Toggle value={doh} onChange={setDoh} color="#10b981" />}
          />
        </Section>

        <Section title="Security & Privacy">
          <SettingItem
            icon={<Lock size={16} className="text-violet-400" />}
            label="App Lock"
            sublabel="PIN or biometric required"
            iconBg="#2d1f5e"
            right={<Toggle value={appLock} onChange={setAppLock} />}
          />
          <SettingItem
            icon={<Shield size={16} className="text-amber-400" />}
            label="18+ Content"
            sublabel={adultMode ? "Enabled" : "Disabled (Restricted Mode)"}
            iconBg="#422006"
            right={<Toggle value={adultMode} onChange={setAdultMode} color="#f59e0b" />}
          />
          <SettingItem
            icon={<Trash2 size={16} className="text-red-400" />}
            label="Clear Browsing Data"
            sublabel="Cookies, history, passwords"
            iconBg="#3b0a0a"
          />
        </Section>

        <Section title="Notifications">
          <SettingItem
            icon={<Bell size={16} className="text-violet-400" />}
            label="Download Alerts"
            sublabel="Notify when complete or failed"
            iconBg="#2d1f5e"
            right={<Toggle value={notifications} onChange={setNotifications} />}
          />
        </Section>

        <Section title="Storage">
          <button
            className="w-full py-3 border-b border-white/5"
            onClick={() => setShowStorageInfo(!showStorageInfo)}
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#14432a] flex items-center justify-center shrink-0">
                <HardDrive size={16} className="text-green-400" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-white" style={{fontSize:'13px',fontWeight:500}}>Storage Used</p>
                <p className="text-gray-500" style={{fontSize:'11px'}}>12.4 GB of 64 GB</p>
                <div className="mt-1 h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full rounded-full" style={{width:'19.4%',background:'linear-gradient(90deg,#10b981,#3b82f6)'}} />
                </div>
              </div>
            </div>
            {showStorageInfo && (
              <div className="mt-3 grid grid-cols-2 gap-2">
                {[
                  { label: "Videos", value: "9.8 GB", color: "#3b82f6" },
                  { label: "Audio", value: "1.2 GB", color: "#10b981" },
                  { label: "Images", value: "840 MB", color: "#f59e0b" },
                  { label: "Vault", value: "560 MB", color: "#8b5cf6" },
                ].map(s => (
                  <div key={s.label} className="flex items-center gap-2 bg-white/5 rounded-xl p-2">
                    <div className="w-2 h-2 rounded-full shrink-0" style={{backgroundColor:s.color}} />
                    <div className="text-left">
                      <p className="text-gray-400" style={{fontSize:'10px'}}>{s.label}</p>
                      <p className="text-white" style={{fontSize:'11px',fontWeight:600}}>{s.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </button>
          <SettingItem
            icon={<Trash2 size={16} className="text-red-400" />}
            label="Clear Cache"
            sublabel="248 MB"
            iconBg="#3b0a0a"
            right={<span className="text-red-400" style={{fontSize:'11px',fontWeight:600}}>Clear</span>}
          />
        </Section>

        <Section title="About">
          <SettingItem icon={<Star size={16} className="text-amber-400" />} label="Rate the App" sublabel="Leave a review" iconBg="#422006" />
          <SettingItem icon={<Share2 size={16} className="text-violet-400" />} label="Share VidGet" sublabel="Invite friends" iconBg="#2d1f5e" />
          <SettingItem icon={<Info size={16} className="text-blue-400" />} label="App Version" sublabel="v2.4.1 — Up to date" iconBg="#1e3a5f" right={<span />} />
        </Section>
      </div>

      {/* Quality Picker */}
      {showQualityPicker && (
        <div className="absolute inset-0 bg-black/70 z-50 flex items-end">
          <div className="w-full bg-[#1a1a24] rounded-t-3xl p-4 border-t border-white/10">
            <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-4" />
            <h3 className="text-white mb-3" style={{fontSize:'15px',fontWeight:700}}>Default Quality</h3>
            <div className="grid grid-cols-4 gap-2 mb-4">
              {qualities.map(q => (
                <button
                  key={q}
                  onClick={() => { setQuality(q); setShowQualityPicker(false); }}
                  className={`py-2.5 rounded-xl text-center border ${q === quality ? "border-violet-500 bg-violet-600/20 text-violet-400" : "border-white/10 bg-white/5 text-gray-400"}`}
                  style={{fontSize:'12px',fontWeight:q===quality?700:400}}
                >
                  {q}
                </button>
              ))}
            </div>
            <button onClick={() => setShowQualityPicker(false)} className="w-full py-2.5 rounded-xl bg-white/10 text-gray-300" style={{fontSize:'13px',fontWeight:600}}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
