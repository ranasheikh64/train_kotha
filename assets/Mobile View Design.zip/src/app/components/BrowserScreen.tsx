import { useState } from "react";
import { ArrowLeft, ArrowRight, RefreshCw, Home, Download, Bookmark, X, Shield, ChevronDown, Plus, Globe, Search, Zap } from "lucide-react";

const TABS = [
  { id: 1, title: "YouTube", url: "youtube.com", favicon: "🎬" },
  { id: 2, title: "Instagram", url: "instagram.com", favicon: "📸" },
];

const bookmarks = [
  { name: "YouTube", url: "youtube.com", favicon: "🎬" },
  { name: "TikTok", url: "tiktok.com", favicon: "🎵" },
  { name: "Twitter/X", url: "twitter.com", favicon: "🐦" },
  { name: "Reddit", url: "reddit.com", favicon: "🤖" },
  { name: "Vimeo", url: "vimeo.com", favicon: "🎞" },
  { name: "Dailymotion", url: "dailymotion.com", favicon: "▶️" },
];

const suggestions = [
  "youtube.com/watch?v=dQw4w9WgXcQ",
  "youtube.com/trending",
  "instagram.com/reels",
  "tiktok.com/@user/video",
];

export default function BrowserScreen() {
  const [tabs, setTabs] = useState(TABS);
  const [activeTabId, setActiveTabId] = useState(1);
  const [urlInput, setUrlInput] = useState("youtube.com");
  const [showTabs, setShowTabs] = useState(false);
  const [showBookmarks, setShowBookmarks] = useState(false);
  const [showSugg, setShowSugg] = useState(false);
  const [isPrivate, setIsPrivate] = useState(false);
  const [detectedMedia, setDetectedMedia] = useState(true);
  const [adBlockOn, setAdBlockOn] = useState(true);

  const activeTab = tabs.find(t => t.id === activeTabId);

  const addNewTab = () => {
    const newId = Date.now();
    setTabs(prev => [...prev, { id: newId, title: "New Tab", url: "", favicon: "🌐" }]);
    setActiveTabId(newId);
    setShowTabs(false);
  };

  const closeTab = (id: number) => {
    const remaining = tabs.filter(t => t.id !== id);
    setTabs(remaining);
    if (activeTabId === id && remaining.length > 0) {
      setActiveTabId(remaining[0].id);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0f0f13] text-white overflow-hidden">
      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 pt-2 pb-1">
        <span className="text-xs text-gray-400">9:41</span>
        <div className="flex items-center gap-2">
          {isPrivate && (
            <span className="text-purple-400 flex items-center gap-1" style={{fontSize:'10px'}}>
              <Shield size={10} /> Private
            </span>
          )}
          <div className="w-5 h-2.5 rounded-sm border border-white/60 p-px">
            <div className="h-full w-4/5 bg-green-400 rounded-sm" />
          </div>
        </div>
      </div>

      {/* Browser Toolbar */}
      <div className={`px-3 pb-2 ${isPrivate ? "bg-[#1a0a2e]" : ""}`}>
        {/* Nav Row */}
        <div className="flex items-center gap-1.5 mb-2">
          <button className="w-8 h-8 rounded-lg bg-white/8 flex items-center justify-center">
            <ArrowLeft size={15} className="text-gray-300" />
          </button>
          <button className="w-8 h-8 rounded-lg bg-white/8 flex items-center justify-center">
            <ArrowRight size={15} className="text-gray-300" />
          </button>
          <div
            className="flex-1 flex items-center gap-2 bg-[#1e1e2a] rounded-xl px-3 py-2 border border-white/10"
            onClick={() => setShowSugg(true)}
          >
            <Globe size={13} className="text-gray-400 shrink-0" />
            <span className="flex-1 text-gray-200 truncate" style={{fontSize:'12px'}}>
              {activeTab?.url || "New Tab"}
            </span>
            {adBlockOn && (
              <span className="shrink-0 px-1.5 py-0.5 rounded bg-green-500/20 text-green-400" style={{fontSize:'9px',fontWeight:600}}>
                Ads Off
              </span>
            )}
          </div>
          <button className="w-8 h-8 rounded-lg bg-white/8 flex items-center justify-center">
            <RefreshCw size={14} className="text-gray-300" />
          </button>
        </div>

        {/* Secondary Row */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowBookmarks(!showBookmarks)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/8"
          >
            <Bookmark size={12} className="text-gray-300" />
          </button>
          <button
            onClick={() => setIsPrivate(!isPrivate)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg ${isPrivate ? "bg-purple-600/30 border border-purple-500/40" : "bg-white/8"}`}
          >
            <Shield size={12} className={isPrivate ? "text-purple-400" : "text-gray-300"} />
            <span style={{fontSize:'10px'}} className={isPrivate ? "text-purple-400" : "text-gray-300"}>
              {isPrivate ? "Private" : "Normal"}
            </span>
          </button>
          <div className="flex-1" />
          <button
            onClick={() => setShowTabs(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/8"
          >
            <span className="text-gray-300" style={{fontSize:'11px',fontWeight:600}}>{tabs.length}</span>
            <ChevronDown size={11} className="text-gray-400" />
          </button>
          <button
            onClick={addNewTab}
            className="w-7 h-7 rounded-lg bg-violet-600 flex items-center justify-center"
          >
            <Plus size={13} className="text-white" />
          </button>
        </div>
      </div>

      {/* Simulated Web Content */}
      <div className="flex-1 overflow-y-auto mx-3 mb-3 rounded-2xl bg-[#1a1a24] border border-white/8 relative" style={{scrollbarWidth:'none'}}>
        {activeTab?.url ? (
          <div className="p-4">
            {/* Fake browser page */}
            <div className="flex items-center gap-2 mb-4 pb-3 border-b border-white/10">
              <div className="text-2xl">{activeTab.favicon}</div>
              <div>
                <p className="text-white" style={{fontSize:'14px',fontWeight:700}}>{activeTab.title}</p>
                <p className="text-gray-400" style={{fontSize:'11px'}}>{activeTab.url}</p>
              </div>
            </div>

            {/* Simulated video cards */}
            {[1,2,3,4].map(i => (
              <div key={i} className="flex gap-3 mb-3 pb-3 border-b border-white/5">
                <div className="w-24 h-16 rounded-lg bg-gradient-to-br from-gray-700 to-gray-800 shrink-0 flex items-center justify-center">
                  <span style={{fontSize:'22px'}}>{["🎬","🎵","⚽","🌍"][i-1]}</span>
                </div>
                <div className="flex-1">
                  <div className="h-3 bg-white/10 rounded mb-1.5 w-4/5" />
                  <div className="h-2.5 bg-white/5 rounded mb-1 w-3/5" />
                  <div className="h-2.5 bg-white/5 rounded w-2/5" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4">
            <p className="text-center text-gray-500 mb-4" style={{fontSize:'13px'}}>New Tab</p>
            <div className="grid grid-cols-3 gap-2">
              {bookmarks.map(b => (
                <button
                  key={b.name}
                  className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-white/5 border border-white/8"
                  onClick={() => {
                    setTabs(prev => prev.map(t => t.id === activeTabId ? { ...t, title: b.name, url: b.url, favicon: b.favicon } : t));
                    setUrlInput(b.url);
                  }}
                >
                  <span style={{fontSize:'20px'}}>{b.favicon}</span>
                  <span className="text-gray-300" style={{fontSize:'10px'}}>{b.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Floating Download Button */}
        {detectedMedia && (
          <button
            className="absolute bottom-3 right-3 flex items-center gap-1.5 px-3 py-2 rounded-full shadow-lg border border-violet-500/40"
            style={{background:"linear-gradient(135deg,#7c3aed,#2563eb)"}}
            onClick={() => setDetectedMedia(false)}
          >
            <Zap size={13} className="text-white" />
            <span className="text-white" style={{fontSize:'11px',fontWeight:600}}>3 videos found</span>
            <X size={12} className="text-white/60 ml-1" onClick={e => { e.stopPropagation(); setDetectedMedia(false); }} />
          </button>
        )}
      </div>

      {/* URL Suggestions Overlay */}
      {showSugg && (
        <div className="absolute inset-0 bg-[#0f0f13]/95 z-40 flex flex-col" onClick={() => setShowSugg(false)}>
          <div className="flex items-center gap-2 mx-3 mt-14 mb-2 bg-[#1e1e2a] rounded-xl px-3 py-2.5 border border-white/10" onClick={e => e.stopPropagation()}>
            <Search size={14} className="text-gray-400" />
            <input
              value={urlInput}
              onChange={e => setUrlInput(e.target.value)}
              className="flex-1 bg-transparent text-white outline-none"
              style={{fontSize:'13px'}}
              autoFocus
            />
            <button onClick={() => setShowSugg(false)}><X size={14} className="text-gray-400" /></button>
          </div>
          {suggestions.map(s => (
            <button
              key={s}
              className="flex items-center gap-3 px-4 py-3 border-b border-white/5"
              onClick={() => {
                setUrlInput(s);
                setShowSugg(false);
                setDetectedMedia(true);
              }}
            >
              <Globe size={14} className="text-gray-500 shrink-0" />
              <span className="text-gray-300" style={{fontSize:'12px'}}>{s}</span>
            </button>
          ))}
        </div>
      )}

      {/* Tabs Modal */}
      {showTabs && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-end">
          <div className="w-full bg-[#1a1a24] rounded-t-3xl p-4 border-t border-white/10 max-h-2/3 overflow-y-auto">
            <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-4" />
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-white" style={{fontSize:'15px',fontWeight:700}}>Tabs ({tabs.length})</h3>
              <button onClick={addNewTab} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-violet-600" style={{fontSize:'12px',fontWeight:600}}>
                <Plus size={12} /> New Tab
              </button>
            </div>
            {tabs.map(tab => (
              <div
                key={tab.id}
                className={`flex items-center gap-2.5 p-3 rounded-xl mb-2 border ${tab.id === activeTabId ? "border-violet-500/40 bg-violet-600/10" : "border-white/8 bg-white/5"}`}
                onClick={() => { setActiveTabId(tab.id); setShowTabs(false); setUrlInput(tab.url); }}
              >
                <span style={{fontSize:'18px'}}>{tab.favicon}</span>
                <div className="flex-1">
                  <p className="text-white" style={{fontSize:'12px',fontWeight:600}}>{tab.title}</p>
                  <p className="text-gray-400" style={{fontSize:'10px'}}>{tab.url || "New tab"}</p>
                </div>
                <button onClick={e => { e.stopPropagation(); closeTab(tab.id); }}>
                  <X size={14} className="text-gray-500" />
                </button>
              </div>
            ))}
            <button onClick={() => setShowTabs(false)} className="w-full py-2.5 rounded-xl bg-white/10 text-gray-300 mt-2" style={{fontSize:'13px',fontWeight:600}}>
              Done
            </button>
          </div>
        </div>
      )}

      {/* Bookmarks Panel */}
      {showBookmarks && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-end">
          <div className="w-full bg-[#1a1a24] rounded-t-3xl p-4 border-t border-white/10">
            <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-4" />
            <h3 className="text-white mb-3" style={{fontSize:'15px',fontWeight:700}}>Bookmarks</h3>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {bookmarks.map(b => (
                <button
                  key={b.name}
                  className="flex flex-col items-center gap-1 p-3 rounded-xl bg-white/8 border border-white/10"
                  onClick={() => setShowBookmarks(false)}
                >
                  <span style={{fontSize:'22px'}}>{b.favicon}</span>
                  <span className="text-gray-300" style={{fontSize:'10px'}}>{b.name}</span>
                </button>
              ))}
            </div>
            <button onClick={() => setShowBookmarks(false)} className="w-full py-2.5 rounded-xl bg-white/10 text-gray-300" style={{fontSize:'13px',fontWeight:600}}>
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
