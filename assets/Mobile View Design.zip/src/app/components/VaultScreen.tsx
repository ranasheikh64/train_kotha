import { useState } from "react";
import { Lock, Fingerprint, Eye, EyeOff, Shield, ChevronLeft } from "lucide-react";

interface VaultScreenProps {
  onBack: () => void;
}

export default function VaultScreen({ onBack }: VaultScreenProps) {
  const [pin, setPin] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [error, setError] = useState(false);

  const CORRECT_PIN = "1234";

  const handleKey = (k: string) => {
    if (k === "del") {
      setPin(prev => prev.slice(0,-1));
      setError(false);
      return;
    }
    const next = pin + k;
    setPin(next);
    if (next.length === 4) {
      if (next === CORRECT_PIN) {
        setUnlocked(true);
      } else {
        setError(true);
        setTimeout(() => { setPin(""); setError(false); }, 600);
      }
    }
  };

  const keypad = [
    ["1","2","3"],
    ["4","5","6"],
    ["7","8","9"],
    ["bio","0","del"],
  ];

  const vaultFiles = [
    { name: "Private_Video_1.mp4", size: "234 MB", thumb: "🔒" },
    { name: "Secret_Clip.mp4", size: "128 MB", thumb: "🔐" },
    { name: "Personal_Photo_Set.zip", size: "88 MB", thumb: "🗝" },
    { name: "Vault_Backup.enc", size: "112 MB", thumb: "💾" },
  ];

  return (
    <div className="flex flex-col h-full bg-[#0a0a12] text-white overflow-hidden">
      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 pt-2 pb-1">
        <span className="text-xs text-gray-400">9:41</span>
        <div className="w-5 h-2.5 rounded-sm border border-white/60 p-px">
          <div className="h-full w-4/5 bg-green-400 rounded-sm" />
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-2">
        <button onClick={onBack} className="w-8 h-8 rounded-xl bg-white/8 flex items-center justify-center">
          <ChevronLeft size={16} className="text-gray-300" />
        </button>
        <h1 className="text-white" style={{fontSize:'17px',fontWeight:700}}>Private Vault</h1>
        <div className="ml-auto flex items-center gap-1.5">
          <Shield size={14} className="text-violet-400" />
          <span className="text-violet-400" style={{fontSize:'11px',fontWeight:600}}>AES-256</span>
        </div>
      </div>

      {!unlocked ? (
        /* PIN Entry */
        <div className="flex flex-col items-center justify-center flex-1 px-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600/30 to-blue-600/30 border border-violet-500/30 flex items-center justify-center mb-6">
            <Lock size={28} className="text-violet-400" />
          </div>
          <p className="text-white mb-1" style={{fontSize:'16px',fontWeight:700}}>Enter Vault PIN</p>
          <p className="text-gray-500 mb-8 text-center" style={{fontSize:'12px'}}>Your files are encrypted with AES-256</p>

          {/* PIN Dots */}
          <div className="flex gap-4 mb-8">
            {[0,1,2,3].map(i => (
              <div
                key={i}
                className={`w-4 h-4 rounded-full border-2 transition-all ${
                  error
                    ? "border-red-500 bg-red-500/40"
                    : pin.length > i
                    ? "border-violet-500 bg-violet-500"
                    : "border-gray-600 bg-transparent"
                }`}
              />
            ))}
          </div>

          {/* Hint text */}
          {error && <p className="text-red-400 mb-4" style={{fontSize:'11px'}}>Incorrect PIN. Try again.</p>}

          {/* Keypad */}
          <div className="grid grid-cols-3 gap-4 w-full max-w-xs">
            {keypad.map((row, ri) =>
              row.map(key => (
                <button
                  key={`${ri}-${key}`}
                  onClick={() => handleKey(key)}
                  className={`h-14 rounded-2xl flex items-center justify-center transition-all active:scale-95 ${
                    key === "bio" || key === "del"
                      ? "bg-white/8"
                      : "bg-[#1a1a24] border border-white/10"
                  }`}
                >
                  {key === "bio" ? (
                    <Fingerprint size={22} className="text-violet-400" />
                  ) : key === "del" ? (
                    <span className="text-gray-300" style={{fontSize:'18px'}}>⌫</span>
                  ) : (
                    <span className="text-white" style={{fontSize:'20px',fontWeight:500}}>{key}</span>
                  )}
                </button>
              ))
            )}
          </div>

          <p className="text-gray-600 mt-6" style={{fontSize:'11px'}}>Try PIN: 1234</p>
        </div>
      ) : (
        /* Vault Contents */
        <div className="flex-1 overflow-y-auto px-4 pb-4" style={{scrollbarWidth:'none'}}>
          <div className="flex items-center gap-2 mb-4 p-3 rounded-xl bg-green-500/10 border border-green-500/20">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-green-400" style={{fontSize:'11px',fontWeight:500}}>Vault unlocked · Auto-locks in 5 min</span>
          </div>

          <p className="text-gray-400 mb-3" style={{fontSize:'12px',fontWeight:600}}>ENCRYPTED FILES</p>
          <div className="space-y-2">
            {vaultFiles.map((file, i) => (
              <div key={i} className="flex items-center gap-3 p-3 rounded-2xl bg-[#1a1a24] border border-white/8">
                <div className="w-10 h-10 rounded-xl bg-violet-600/20 flex items-center justify-center" style={{fontSize:'20px'}}>
                  {file.thumb}
                </div>
                <div className="flex-1">
                  <p className="text-white" style={{fontSize:'12px',fontWeight:500}}>{file.name}</p>
                  <p className="text-gray-500" style={{fontSize:'10px'}}>{file.size} · Encrypted</p>
                </div>
                <Lock size={13} className="text-violet-400 shrink-0" />
              </div>
            ))}
          </div>

          <div className="mt-4 p-3 rounded-2xl bg-[#1a1a24] border border-white/8">
            <p className="text-gray-400 mb-2" style={{fontSize:'11px',fontWeight:600}}>VAULT STATS</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Total Files", value: "4" },
                { label: "Storage Used", value: "562 MB" },
                { label: "Encryption", value: "AES-256" },
                { label: "Key Storage", value: "Keystore" },
              ].map(s => (
                <div key={s.label} className="bg-white/5 rounded-xl p-2.5">
                  <p className="text-gray-500" style={{fontSize:'10px'}}>{s.label}</p>
                  <p className="text-white" style={{fontSize:'12px',fontWeight:600}}>{s.value}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => setUnlocked(false)}
            className="w-full mt-4 py-3 rounded-xl bg-white/8 border border-white/10 text-gray-400 flex items-center justify-center gap-2"
            style={{fontSize:'13px',fontWeight:500}}
          >
            <Lock size={14} />
            Lock Vault
          </button>
        </div>
      )}
    </div>
  );
}
