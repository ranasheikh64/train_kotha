import { useState } from "react";
import { Search, Mic, Bell, Play, Download, TrendingUp, Music, Film, Image, Tv, Trophy, Newspaper, ChevronRight, Clock, Star } from "lucide-react";

const thumbnails = {
  cinematic: "https://images.unsplash.com/photo-1508155400085-a226abc22e2a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWF0aWMlMjB2aWRlbyUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3NzY1OTU0ODd8MA&ixlib=rb-4.1.0&q=80&w=400",
  music: "https://images.unsplash.com/photo-1689793354800-de168c0a4c9b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGNvbmNlcnQlMjBzdGFnZSUyMGxpZ2h0c3xlbnwxfHx8fDE3NzY1OTU0ODd8MA&ixlib=rb-4.1.0&q=80&w=400",
  sports: "https://images.unsplash.com/photo-1710789056962-ccee0cef42a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcG9ydHMlMjBmb290YmFsbCUyMGFjdGlvbnxlbnwxfHx8fDE3NzY1OTU0ODd8MA&ixlib=rb-4.1.0&q=80&w=400",
  travel: "https://images.unsplash.com/photo-1596465100959-08e5bd495b38?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmF2ZWwlMjBuYXR1cmUlMjBzY2VuZXJ5fGVufDF8fHx8MTc3NjU5NTQ4OHww&ixlib=rb-4.1.0&q=80&w=400",
  tech: "https://images.unsplash.com/photo-1758186355698-bd0183fc75ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwZ2FkZ2V0JTIwcmV2aWV3fGVufDF8fHx8MTc3NjU5NTQ4OHww&ixlib=rb-4.1.0&q=80&w=400",
  food: "https://images.unsplash.com/photo-1635661988046-306631057df3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb29raW5nJTIwZm9vZCUyMHJlY2lwZXxlbnwxfHx8fDE3NzY1OTU0ODl8MA&ixlib=rb-4.1.0&q=80&w=400",
};

const tabs = [
  { id: "trending", label: "Trending", icon: TrendingUp },
  { id: "movies", label: "Movies", icon: Film },
  { id: "music", label: "Music", icon: Music },
  { id: "images", label: "Images", icon: Image },
  { id: "live", label: "Live TV", icon: Tv },
  { id: "sports", label: "Sports", icon: Trophy },
  { id: "news", label: "News", icon: Newspaper },
];

const trendingVideos = [
  { id: 1, title: "Epic Mountain Timelapse — 4K Cinematic", channel: "Nature Films", views: "12.4M", duration: "8:32", quality: "4K", thumb: thumbnails.cinematic },
  { id: 2, title: "World Tour 2024 — Live Concert Highlights", channel: "MusicLive", views: "8.1M", duration: "45:12", quality: "1080p", thumb: thumbnails.music },
  { id: 3, title: "Champions League Final — Best Moments", channel: "SportsCentral", views: "21.7M", duration: "12:05", quality: "1080p", thumb: thumbnails.sports },
  { id: 4, title: "Hidden Gems of Southeast Asia", channel: "TravelVlog", views: "3.2M", duration: "18:44", quality: "720p", thumb: thumbnails.travel },
  { id: 5, title: "iPhone 17 Pro — Full In-Depth Review", channel: "TechInsider", views: "6.5M", duration: "22:17", quality: "1080p", thumb: thumbnails.tech },
  { id: 6, title: "Gordon Ramsay's Secret Pasta Recipe", channel: "FoodMasters", views: "15.8M", duration: "14:30", quality: "720p", thumb: thumbnails.food },
];

const quickPaste = [
  "youtube.com", "instagram.com", "tiktok.com", "twitter.com"
];

export default function HomeScreen() {
  const [activeTab, setActiveTab] = useState("trending");
  const [urlInput, setUrlInput] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [downloadingId, setDownloadingId] = useState<number | null>(null);

  const handleDownload = (id: number) => {
    setDownloadingId(id);
    setTimeout(() => setDownloadingId(null), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#0f0f13] text-white overflow-hidden">
      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 pt-2 pb-1">
        <span className="text-xs text-gray-400">9:41</span>
        <div className="flex items-center gap-1">
          <div className="flex gap-0.5 items-end">
            <div className="w-0.5 h-1 bg-white rounded-sm opacity-40" />
            <div className="w-0.5 h-1.5 bg-white rounded-sm opacity-60" />
            <div className="w-0.5 h-2 bg-white rounded-sm opacity-80" />
            <div className="w-0.5 h-2.5 bg-white rounded-sm" />
          </div>
          <svg className="w-3 h-3 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M1.5 8.5a13 13 0 0121 0M5 12a9 9 0 0114 0M8.5 15.5a5 5 0 017 0M12 19h.01" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none"/></svg>
          <div className="flex items-center gap-0.5 ml-1">
            <div className="w-5 h-2.5 rounded-sm border border-white/60 p-px">
              <div className="h-full w-4/5 bg-green-400 rounded-sm" />
            </div>
          </div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500 to-blue-600 flex items-center justify-center">
            <Download size={14} className="text-white" />
          </div>
          <span className="text-white" style={{fontSize:'15px',fontWeight:700}}>VidGet</span>
        </div>
        <button className="relative p-1.5 rounded-full bg-white/10">
          <Bell size={16} className="text-white" />
          <span className="absolute top-0.5 right-0.5 w-2 h-2 bg-violet-500 rounded-full" />
        </button>
      </div>

      {/* URL Input Bar */}
      <div className="px-4 pb-3">
        <div className="flex items-center gap-2 bg-[#1e1e2a] rounded-xl px-3 py-2.5 border border-white/10">
          <Search size={15} className="text-gray-400 shrink-0" />
          <input
            value={urlInput}
            onChange={e => { setUrlInput(e.target.value); setShowSuggestions(e.target.value.length > 0); }}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
            placeholder="Paste URL or search..."
            className="flex-1 bg-transparent text-white placeholder:text-gray-500 outline-none min-w-0"
            style={{fontSize:'13px'}}
          />
          <button className="p-1 rounded-lg bg-white/10">
            <Mic size={13} className="text-gray-400" />
          </button>
          {urlInput && (
            <button
              onClick={() => handleDownload(0)}
              className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-violet-600 to-blue-600 text-white shrink-0"
              style={{fontSize:'11px',fontWeight:600}}
            >
              Go
            </button>
          )}
        </div>
        {/* Quick paste chips */}
        {!showSuggestions && (
          <div className="flex gap-2 mt-2 overflow-x-auto no-scrollbar">
            {quickPaste.map(site => (
              <button
                key={site}
                onClick={() => setUrlInput(`https://www.${site}/watch`)}
                className="shrink-0 px-2.5 py-1 rounded-full bg-white/8 border border-white/10 text-gray-400"
                style={{fontSize:'11px'}}
              >
                {site}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 px-4 overflow-x-auto no-scrollbar pb-2">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition-all ${
                active
                  ? "bg-violet-600 border-violet-600 text-white"
                  : "bg-transparent border-white/15 text-gray-400"
              }`}
              style={{fontSize:'11px',fontWeight:active?600:400}}
            >
              <Icon size={11} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Scrollable Feed */}
      <div className="flex-1 overflow-y-auto px-4 pb-2 space-y-3" style={{scrollbarWidth:'none'}}>
        {/* Section Header */}
        <div className="flex items-center justify-between pt-1">
          <span style={{fontSize:'13px',fontWeight:600}} className="text-white">Trending Now</span>
          <button className="flex items-center gap-0.5 text-violet-400" style={{fontSize:'11px'}}>
            See all <ChevronRight size={12} />
          </button>
        </div>

        {/* Featured Card */}
        <div className="relative rounded-2xl overflow-hidden">
          <img src={thumbnails.cinematic} alt="featured" className="w-full h-36 object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute bottom-2 left-3 right-3">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="px-1.5 py-0.5 rounded bg-red-500 text-white" style={{fontSize:'9px',fontWeight:700}}>LIVE</span>
              <span className="px-1.5 py-0.5 rounded bg-violet-600 text-white" style={{fontSize:'9px',fontWeight:600}}>4K</span>
            </div>
            <p className="text-white" style={{fontSize:'12px',fontWeight:600}}>Epic Mountain Timelapse — 4K Cinematic</p>
            <div className="flex items-center justify-between mt-1">
              <span className="text-gray-300" style={{fontSize:'10px'}}>Nature Films • 12.4M views</span>
              <button
                onClick={() => handleDownload(1)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-violet-600 to-blue-600"
                style={{fontSize:'10px',fontWeight:600}}
              >
                {downloadingId === 1 ? (
                  <span className="animate-pulse">Added!</span>
                ) : (
                  <><Download size={10} /> Download</>
                )}
              </button>
            </div>
          </div>
          <button className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center backdrop-blur-sm border border-white/20">
            <Play size={18} className="text-white ml-0.5" fill="white" />
          </button>
        </div>

        {/* Video List */}
        <div className="flex items-center justify-between">
          <span style={{fontSize:'13px',fontWeight:600}} className="text-white">More Videos</span>
        </div>
        {trendingVideos.slice(1).map(video => (
          <div key={video.id} className="flex gap-3 items-start">
            <div className="relative shrink-0 rounded-xl overflow-hidden" style={{width:100,height:64}}>
              <img src={video.thumb} alt={video.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/20" />
              <div className="absolute bottom-1 right-1 px-1 py-0.5 rounded bg-black/70 text-white" style={{fontSize:'9px'}}>
                {video.duration}
              </div>
              <button className="absolute inset-0 flex items-center justify-center">
                <div className="w-7 h-7 rounded-full bg-black/50 flex items-center justify-center border border-white/30">
                  <Play size={11} className="text-white ml-0.5" fill="white" />
                </div>
              </button>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white leading-tight line-clamp-2" style={{fontSize:'12px',fontWeight:500}}>{video.title}</p>
              <p className="text-gray-400 mt-0.5" style={{fontSize:'10px'}}>{video.channel}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="flex items-center gap-0.5 text-gray-500" style={{fontSize:'10px'}}>
                  <Clock size={9} /> {video.views}
                </span>
                <span className="px-1.5 py-0.5 rounded bg-white/10 text-gray-300" style={{fontSize:'9px'}}>{video.quality}</span>
              </div>
            </div>
            <button
              onClick={() => handleDownload(video.id)}
              className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-violet-600/20 border border-violet-500/30"
            >
              {downloadingId === video.id ? (
                <Star size={13} className="text-yellow-400" fill="currentColor" />
              ) : (
                <Download size={13} className="text-violet-400" />
              )}
            </button>
          </div>
        ))}

        {/* Recently Downloaded */}
        <div className="flex items-center justify-between pt-2">
          <span style={{fontSize:'13px',fontWeight:600}} className="text-white">Recently Downloaded</span>
          <button className="flex items-center gap-0.5 text-violet-400" style={{fontSize:'11px'}}>
            See all <ChevronRight size={12} />
          </button>
        </div>
        <div className="flex gap-2.5 overflow-x-auto pb-1" style={{scrollbarWidth:'none'}}>
          {[thumbnails.tech, thumbnails.food, thumbnails.music].map((thumb, i) => (
            <div key={i} className="shrink-0 rounded-xl overflow-hidden relative" style={{width:90,height:70}}>
              <img src={thumb} alt="" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
              <div className="absolute bottom-1 left-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block mr-1" />
                <span className="text-white" style={{fontSize:'8px'}}>Done</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
