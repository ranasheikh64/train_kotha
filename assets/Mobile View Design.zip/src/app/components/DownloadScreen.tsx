import { useState, useEffect } from "react";
import { Download, Pause, Play, X, CheckCircle, Clock, ChevronDown, Wifi, WifiOff, MoreVertical, Plus, RefreshCw, AlertCircle } from "lucide-react";

type DownloadStatus = "downloading" | "paused" | "completed" | "failed" | "queued";

interface DownloadItem {
  id: number;
  title: string;
  site: string;
  format: string;
  quality: string;
  size: string;
  progress: number;
  speed: string;
  eta: string;
  status: DownloadStatus;
  icon: string;
}

const initialDownloads: DownloadItem[] = [
  { id: 1, title: "Epic Mountain Timelapse 4K", site: "YouTube", format: "MP4", quality: "4K", size: "1.2 GB", progress: 67, speed: "4.3 MB/s", eta: "3m 12s", status: "downloading", icon: "🎬" },
  { id: 2, title: "World Tour Concert Highlights", site: "Instagram", format: "MP4", quality: "1080p", size: "648 MB", progress: 34, speed: "2.1 MB/s", eta: "5m 41s", status: "downloading", icon: "🎵" },
  { id: 3, title: "Champions League Final", site: "Facebook", format: "MP4", quality: "1080p", size: "980 MB", progress: 0, speed: "—", eta: "—", status: "queued", icon: "⚽" },
  { id: 4, title: "iPhone 17 Pro Review", site: "YouTube", format: "MP4", quality: "1080p", size: "324 MB", progress: 100, speed: "—", eta: "—", status: "completed", icon: "📱" },
  { id: 5, title: "Gordon Ramsay Pasta Recipe", site: "TikTok", format: "MP4", quality: "720p", size: "87 MB", progress: 100, speed: "—", eta: "—", status: "completed", icon: "🍝" },
  { id: 6, title: "Hidden Gems Southeast Asia", site: "Vimeo", format: "MP4", quality: "720p", size: "512 MB", progress: 22, speed: "—", eta: "—", status: "failed", icon: "🌏" },
];

const statusColors: Record<DownloadStatus, string> = {
  downloading: "#8b5cf6",
  paused: "#f59e0b",
  completed: "#10b981",
  failed: "#ef4444",
  queued: "#6b7280",
};

const filterTabs = ["All", "Active", "Completed", "Failed"];

export default function DownloadScreen() {
  const [downloads, setDownloads] = useState<DownloadItem[]>(initialDownloads);
  const [activeFilter, setActiveFilter] = useState("All");
  const [wifiOnly, setWifiOnly] = useState(true);
  const [showAddUrl, setShowAddUrl] = useState(false);
  const [newUrl, setNewUrl] = useState("");

  useEffect(() => {
    const interval = setInterval(() => {
      setDownloads(prev => prev.map(d => {
        if (d.status === "downloading" && d.progress < 100) {
          const newProgress = Math.min(d.progress + Math.random() * 3, 100);
          return {
            ...d,
            progress: Math.round(newProgress),
            status: newProgress >= 100 ? "completed" : "downloading",
          };
        }
        return d;
      }));
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  const togglePause = (id: number) => {
    setDownloads(prev => prev.map(d => {
      if (d.id !== id) return d;
      if (d.status === "downloading") return { ...d, status: "paused" };
      if (d.status === "paused") return { ...d, status: "downloading" };
      return d;
    }));
  };

  const removeDownload = (id: number) => {
    setDownloads(prev => prev.filter(d => d.id !== id));
  };

  const retryDownload = (id: number) => {
    setDownloads(prev => prev.map(d =>
      d.id === id ? { ...d, status: "downloading", progress: 0 } : d
    ));
  };

  const filteredDownloads = downloads.filter(d => {
    if (activeFilter === "All") return true;
    if (activeFilter === "Active") return d.status === "downloading" || d.status === "paused" || d.status === "queued";
    if (activeFilter === "Completed") return d.status === "completed";
    if (activeFilter === "Failed") return d.status === "failed";
    return true;
  });

  const totalSpeed = downloads
    .filter(d => d.status === "downloading")
    .reduce((sum, d) => sum + parseFloat(d.speed), 0).toFixed(1);

  const activeCount = downloads.filter(d => d.status === "downloading").length;
  const completedCount = downloads.filter(d => d.status === "completed").length;

  return (
    <div className="flex flex-col h-full bg-[#0f0f13] text-white overflow-hidden">
      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 pt-2 pb-1">
        <span className="text-xs text-gray-400">9:41</span>
        <div className="flex items-center gap-1">
          <div className="w-5 h-2.5 rounded-sm border border-white/60 p-px">
            <div className="h-full w-4/5 bg-green-400 rounded-sm" />
          </div>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2">
        <h1 className="text-white" style={{fontSize:'17px',fontWeight:700}}>Downloads</h1>
        <div className="flex gap-2">
          <button
            onClick={() => setWifiOnly(!wifiOnly)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border ${wifiOnly ? "bg-violet-600/20 border-violet-500/40 text-violet-400" : "bg-white/10 border-white/15 text-gray-400"}`}
            style={{fontSize:'11px'}}
          >
            {wifiOnly ? <Wifi size={11} /> : <WifiOff size={11} />}
            {wifiOnly ? "Wi-Fi" : "Data"}
          </button>
          <button
            onClick={() => setShowAddUrl(true)}
            className="w-8 h-8 rounded-full bg-violet-600 flex items-center justify-center"
          >
            <Plus size={15} className="text-white" />
          </button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="mx-4 mb-3 rounded-xl bg-[#1a1a24] p-3 border border-white/8">
        <div className="grid grid-cols-3 gap-2 text-center">
          <div>
            <p className="text-violet-400" style={{fontSize:'16px',fontWeight:700}}>{activeCount}</p>
            <p className="text-gray-500" style={{fontSize:'10px'}}>Active</p>
          </div>
          <div className="border-x border-white/10">
            <p className="text-green-400" style={{fontSize:'16px',fontWeight:700}}>{completedCount}</p>
            <p className="text-gray-500" style={{fontSize:'10px'}}>Done</p>
          </div>
          <div>
            <p className="text-white" style={{fontSize:'16px',fontWeight:700}}>{totalSpeed}</p>
            <p className="text-gray-500" style={{fontSize:'10px'}}>MB/s</p>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 px-4 mb-3">
        {filterTabs.map(tab => (
          <button
            key={tab}
            onClick={() => setActiveFilter(tab)}
            className={`flex-1 py-1.5 rounded-lg text-center transition-all ${activeFilter === tab ? "bg-violet-600 text-white" : "bg-white/8 text-gray-400"}`}
            style={{fontSize:'11px',fontWeight:activeFilter===tab?600:400}}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Download List */}
      <div className="flex-1 overflow-y-auto px-4 space-y-2.5 pb-4" style={{scrollbarWidth:'none'}}>
        {filteredDownloads.map(item => (
          <div key={item.id} className="bg-[#1a1a24] rounded-2xl p-3 border border-white/8">
            <div className="flex items-start gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center shrink-0" style={{fontSize:'18px'}}>
                {item.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white leading-tight line-clamp-1" style={{fontSize:'12px',fontWeight:600}}>{item.title}</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-gray-400" style={{fontSize:'10px'}}>{item.site}</span>
                  <span className="text-gray-600">·</span>
                  <span className="px-1 py-0.5 rounded bg-white/10 text-gray-300" style={{fontSize:'9px'}}>{item.quality}</span>
                  <span className="px-1 py-0.5 rounded bg-white/10 text-gray-300" style={{fontSize:'9px'}}>{item.format}</span>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                {(item.status === "downloading" || item.status === "paused") && (
                  <button
                    onClick={() => togglePause(item.id)}
                    className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center"
                  >
                    {item.status === "downloading"
                      ? <Pause size={12} className="text-white" />
                      : <Play size={12} className="text-white ml-0.5" />
                    }
                  </button>
                )}
                {item.status === "failed" && (
                  <button
                    onClick={() => retryDownload(item.id)}
                    className="w-7 h-7 rounded-full bg-red-500/20 flex items-center justify-center"
                  >
                    <RefreshCw size={12} className="text-red-400" />
                  </button>
                )}
                <button
                  onClick={() => removeDownload(item.id)}
                  className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center"
                >
                  <X size={12} className="text-gray-400" />
                </button>
              </div>
            </div>

            {/* Progress */}
            {item.status !== "queued" && (
              <div className="mt-2.5">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    {item.status === "completed" && <CheckCircle size={11} className="text-green-400" />}
                    {item.status === "failed" && <AlertCircle size={11} className="text-red-400" />}
                    {item.status === "downloading" && <Download size={11} className="text-violet-400" />}
                    {item.status === "paused" && <Pause size={11} className="text-amber-400" />}
                    <span style={{fontSize:'10px', color: statusColors[item.status], fontWeight:500}}>
                      {item.status === "downloading" ? `${item.speed} • ${item.eta} left` :
                       item.status === "paused" ? "Paused" :
                       item.status === "completed" ? `Completed • ${item.size}` :
                       "Failed — tap retry"}
                    </span>
                  </div>
                  <span className="text-gray-400" style={{fontSize:'10px'}}>{item.progress}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{
                      width: `${item.progress}%`,
                      background: item.status === "completed"
                        ? "linear-gradient(90deg,#10b981,#059669)"
                        : item.status === "failed"
                        ? "#ef4444"
                        : "linear-gradient(90deg,#8b5cf6,#3b82f6)"
                    }}
                  />
                </div>
              </div>
            )}
            {item.status === "queued" && (
              <div className="mt-2 flex items-center gap-1.5">
                <Clock size={11} className="text-gray-500" />
                <span className="text-gray-500" style={{fontSize:'10px'}}>Queued • {item.size} • {item.quality}</span>
              </div>
            )}
          </div>
        ))}

        {filteredDownloads.length === 0 && (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <Download size={32} className="text-gray-600 mb-3" />
            <p className="text-gray-400" style={{fontSize:'13px',fontWeight:500}}>No downloads here</p>
            <p className="text-gray-600" style={{fontSize:'11px'}}>Paste a URL on the Home tab</p>
          </div>
        )}
      </div>

      {/* Add URL Modal */}
      {showAddUrl && (
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex items-end z-50">
          <div className="w-full bg-[#1a1a24] rounded-t-3xl p-5 border-t border-white/10">
            <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-4" />
            <h3 className="text-white mb-3" style={{fontSize:'15px',fontWeight:700}}>Add Download</h3>
            <div className="flex items-center gap-2 bg-[#0f0f13] rounded-xl px-3 py-2.5 border border-white/10 mb-3">
              <input
                value={newUrl}
                onChange={e => setNewUrl(e.target.value)}
                placeholder="Paste URL here..."
                className="flex-1 bg-transparent text-white placeholder:text-gray-600 outline-none"
                style={{fontSize:'13px'}}
                autoFocus
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => { setShowAddUrl(false); setNewUrl(""); }}
                className="flex-1 py-2.5 rounded-xl bg-white/10 text-gray-300"
                style={{fontSize:'13px',fontWeight:600}}
              >
                Cancel
              </button>
              <button
                onClick={() => { setShowAddUrl(false); setNewUrl(""); }}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-blue-600 text-white"
                style={{fontSize:'13px',fontWeight:600}}
              >
                Download
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
