import { useState } from "react";
import {
  Home,
  Download,
  Globe,
  FolderOpen,
  Settings,
  Lock,
} from "lucide-react";
import HomeScreen from "./components/HomeScreen";
import DownloadScreen from "./components/DownloadScreen";
import BrowserScreen from "./components/BrowserScreen";
import FilesScreen from "./components/FilesScreen";
import SettingsScreen from "./components/SettingsScreen";
import VaultScreen from "./components/VaultScreen";

type Tab =
  | "home"
  | "downloads"
  | "browser"
  | "files"
  | "settings";

const navItems: {
  id: Tab;
  label: string;
  icon: typeof Home;
}[] = [
  { id: "home", label: "Home", icon: Home },
  { id: "downloads", label: "Downloads", icon: Download },
  { id: "browser", label: "Browser", icon: Globe },
  { id: "files", label: "Files", icon: FolderOpen },
  { id: "settings", label: "Settings", icon: Settings },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [showVault, setShowVault] = useState(false);

  const renderScreen = () => {
    if (showVault)
      return <VaultScreen onBack={() => setShowVault(false)} />;
    switch (activeTab) {
      case "home":
        return <HomeScreen />;
      case "downloads":
        return <DownloadScreen />;
      case "browser":
        return <BrowserScreen />;
      case "files":
        return <FilesScreen />;
      case "settings":
        return <SettingsScreen />;
    }
  };

  return (
    <div
      className="w-full h-full min-h-screen flex items-center justify-center bg-[#060608]"
      style={{
        background:
          "radial-gradient(ellipse at center, #0d0d1a 0%, #060608 100%)",
      }}
    >
      {/* Glow effect behind phone */}
      <div
        className="absolute rounded-full blur-3xl opacity-20 pointer-events-none"
        style={{
          width: 320,
          height: 320,
          background:
            "radial-gradient(circle, #7c3aed, #2563eb)",
        }}
      />

      {/* Phone Frame */}
      <div
        className="relative flex flex-col overflow-hidden shadow-2xl"
        style={{
          width: 390,
          height: 844,
          borderRadius: 52,
          background: "#0f0f13",
          boxShadow:
            "0 0 0 1px rgba(255,255,255,0.12), 0 0 0 3px #1a1a2e, 0 40px 80px rgba(0,0,0,0.8), inset 0 1px 0 rgba(255,255,255,0.08)",
        }}
      >
        {/* Notch/Dynamic Island */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-50">
          <div
            className="bg-black rounded-full"
            style={{ width: 120, height: 36, borderRadius: 20 }}
          />
        </div>

        {/* Screen Content */}
        <div className="flex-1 flex flex-col overflow-hidden pt-10">
          {/* Active Screen */}
          <div className="flex-1 overflow-hidden relative">
            {renderScreen()}
          </div>

          {/* Bottom Navigation */}
          {!showVault && (
            <div
              className="shrink-0 flex items-center px-2 pt-2 pb-1 border-t border-white/8"
              style={{
                background: "rgba(15,15,19,0.95)",
                backdropFilter: "blur(20px)",
              }}
            >
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setShowVault(false);
                    }}
                    className="flex-1 flex flex-col items-center gap-0.5 py-1.5 rounded-xl transition-all"
                  >
                    <div
                      className={`relative flex items-center justify-center w-8 h-8 rounded-xl transition-all ${active ? "bg-violet-600/20" : ""}`}
                    >
                      <Icon
                        size={18}
                        className={`transition-all ${active ? "text-violet-400" : "text-gray-500"}`}
                        strokeWidth={active ? 2.5 : 1.8}
                      />
                      {item.id === "downloads" && (
                        <span
                          className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-violet-600 text-white flex items-center justify-center"
                          style={{
                            fontSize: "8px",
                            fontWeight: 700,
                          }}
                        >
                          2
                        </span>
                      )}
                    </div>
                    <span
                      style={{
                        fontSize: "9px",
                        fontWeight: active ? 600 : 400,
                      }}
                      className={
                        active
                          ? "text-violet-400"
                          : "text-gray-600"
                      }
                    >
                      {item.label}
                    </span>
                  </button>
                );
              })}
              {/* Vault button */}
              <button
                onClick={() => setShowVault(true)}
                className="flex-1 flex flex-col items-center gap-0.5 py-1.5 rounded-xl transition-all"
              >
                <div
                  className={`relative flex items-center justify-center w-8 h-8 rounded-xl transition-all ${showVault ? "bg-violet-600/20" : ""}`}
                >
                  <Lock
                    size={18}
                    className={`transition-all ${showVault ? "text-violet-400" : "text-gray-500"}`}
                    strokeWidth={showVault ? 2.5 : 1.8}
                  />
                </div>
                <span
                  style={{
                    fontSize: "9px",
                    fontWeight: showVault ? 600 : 400,
                  }}
                  className={
                    showVault
                      ? "text-violet-400"
                      : "text-gray-600"
                  }
                >
                  Vault
                </span>
              </button>
            </div>
          )}

          {/* Home Indicator */}
          <div className="flex justify-center pb-2 pt-1 shrink-0">
            <div className="w-24 h-1 bg-white/20 rounded-full" />
          </div>
        </div>
      </div>

      {/* Desktop label */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-center">
        <p
          className="text-gray-600"
          style={{ fontSize: "12px" }}
        >
          VidGet · Mobile Preview
        </p>
      </div>
    </div>
  );
}